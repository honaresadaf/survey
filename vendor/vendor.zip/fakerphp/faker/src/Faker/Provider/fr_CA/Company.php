<?php

namespace Faker\Provider\fr_CA;

class Company extends \Faker\Provider\fr_FR\Company
{
}
